package com.ritesh.mindrise.domain.model

/**
 * Domain model representing a user habit.
 */
data class Habit(
    val id: Long = 0,
    val title: String,
    val description: String,
    val category: String,
    val reminderTime: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Domain model representing a habit completion record.
 */
data class HabitCompletion(
    val id: Long = 0,
    val habitId: Long,
    val date: String,
    val completed: Boolean = false
)

/**
 * Combined model for displaying habit with its completion status for today.
 */
data class HabitWithStatus(
    val habit: Habit,
    val isCompletedToday: Boolean = false,
    val currentStreak: Int = 0
)

/**
 * Dashboard summary stats.
 */
data class DashboardStats(
    val totalHabits: Int = 0,
    val completedToday: Int = 0,
    val longestStreak: Int = 0,
    val completionRate: Float = 0f
)

/**
 * Weekly analytics data point.
 */
data class WeeklyData(
    val dayLabel: String,
    val completedCount: Int,
    val totalCount: Int
)

/**
 * Categories available for habits.
 */
enum class HabitCategory(val displayName: String, val emoji: String) {
    HEALTH("Health", "💪"),
    MINDFULNESS("Mindfulness", "🧘"),
    LEARNING("Learning", "📚"),
    FITNESS("Fitness", "🏃"),
    PRODUCTIVITY("Productivity", "⚡"),
    SOCIAL("Social", "👥"),
    CREATIVITY("Creativity", "🎨"),
    FINANCE("Finance", "💰"),
    OTHER("Other", "✨")
}
