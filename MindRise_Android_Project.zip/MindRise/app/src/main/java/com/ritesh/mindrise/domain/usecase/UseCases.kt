package com.ritesh.mindrise.domain.usecase

import com.ritesh.mindrise.domain.model.*
import com.ritesh.mindrise.domain.repository.HabitRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

class GetAllHabitsUseCase @Inject constructor(private val repo: HabitRepository) {
    operator fun invoke(): Flow<List<Habit>> = repo.getAllHabits()
}

class AddHabitUseCase @Inject constructor(private val repo: HabitRepository) {
    suspend operator fun invoke(habit: Habit): Long = repo.addHabit(habit)
}

class DeleteHabitUseCase @Inject constructor(private val repo: HabitRepository) {
    suspend operator fun invoke(habit: Habit) = repo.deleteHabit(habit)
}

class ToggleHabitCompletionUseCase @Inject constructor(private val repo: HabitRepository) {
    suspend operator fun invoke(habitId: Long, date: String) =
        repo.toggleHabitCompletion(habitId, date)
}

class GetDashboardStatsUseCase @Inject constructor(private val repo: HabitRepository) {
    operator fun invoke(): Flow<DashboardStats> {
        val today = LocalDate.now().format(DATE_FMT)
        return combine(
            repo.getTotalHabitsCount(),
            repo.getCompletedCountForDate(today)
        ) { total, completedToday ->
            DashboardStats(
                totalHabits = total,
                completedToday = completedToday,
                longestStreak = 0, // computed lazily in VM
                completionRate = if (total > 0) completedToday.toFloat() / total else 0f
            )
        }
    }
}

class GetHabitsWithStatusUseCase @Inject constructor(private val repo: HabitRepository) {
    operator fun invoke(): Flow<List<HabitWithStatus>> {
        val today = LocalDate.now().format(DATE_FMT)
        return combine(
            repo.getAllHabits(),
            repo.getCompletionsForDate(today)
        ) { habits, completions ->
            val completedIds = completions.filter { it.completed }.map { it.habitId }.toSet()
            habits.map { habit ->
                HabitWithStatus(
                    habit = habit,
                    isCompletedToday = habit.id in completedIds,
                    currentStreak = 0
                )
            }
        }
    }
}

class GetWeeklyAnalyticsUseCase @Inject constructor(private val repo: HabitRepository) {
    operator fun invoke(): Flow<List<WeeklyData>> {
        val today = LocalDate.now()
        val startOfWeek = today.minusDays(6)
        val startStr = startOfWeek.format(DATE_FMT)
        val endStr = today.format(DATE_FMT)

        return combine(
            repo.getAllCompletionsInRange(startStr, endStr),
            repo.getTotalHabitsCount()
        ) { completions, totalHabits ->
            (0..6).map { offset ->
                val date = startOfWeek.plusDays(offset.toLong())
                val dateStr = date.format(DATE_FMT)
                val dayCompletions = completions.filter { it.date == dateStr && it.completed }
                WeeklyData(
                    dayLabel = date.dayOfWeek.name.take(3),
                    completedCount = dayCompletions.size,
                    totalCount = totalHabits
                )
            }
        }
    }
}
