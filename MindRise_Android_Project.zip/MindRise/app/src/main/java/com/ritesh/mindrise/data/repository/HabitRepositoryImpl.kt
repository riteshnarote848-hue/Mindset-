package com.ritesh.mindrise.data.repository

import com.ritesh.mindrise.data.local.dao.HabitCompletionDao
import com.ritesh.mindrise.data.local.dao.HabitDao
import com.ritesh.mindrise.data.local.entity.HabitCompletionEntity
import com.ritesh.mindrise.data.local.entity.HabitEntity
import com.ritesh.mindrise.domain.model.Habit
import com.ritesh.mindrise.domain.model.HabitCompletion
import com.ritesh.mindrise.domain.repository.HabitRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementation of HabitRepository using Room as data source.
 */
@Singleton
class HabitRepositoryImpl @Inject constructor(
    private val habitDao: HabitDao,
    private val completionDao: HabitCompletionDao
) : HabitRepository {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    // ──────────────────────────────────────────────────────────────────────────
    // Mapping helpers
    // ──────────────────────────────────────────────────────────────────────────

    private fun HabitEntity.toDomain() = Habit(
        id = id, title = title, description = description,
        category = category, reminderTime = reminderTime, createdAt = createdAt
    )

    private fun Habit.toEntity() = HabitEntity(
        id = id, title = title, description = description,
        category = category, reminderTime = reminderTime, createdAt = createdAt
    )

    private fun HabitCompletionEntity.toDomain() = HabitCompletion(
        id = id, habitId = habitId, date = date, completed = completed
    )

    // ──────────────────────────────────────────────────────────────────────────
    // Habit CRUD
    // ──────────────────────────────────────────────────────────────────────────

    override fun getAllHabits(): Flow<List<Habit>> =
        habitDao.getAllHabits().map { list -> list.map { it.toDomain() } }

    override suspend fun getHabitById(id: Long): Habit? =
        habitDao.getHabitById(id)?.toDomain()

    override suspend fun addHabit(habit: Habit): Long =
        habitDao.insertHabit(habit.toEntity())

    override suspend fun updateHabit(habit: Habit) =
        habitDao.updateHabit(habit.toEntity())

    override suspend fun deleteHabit(habit: Habit) =
        habitDao.deleteHabit(habit.toEntity())

    override fun getTotalHabitsCount(): Flow<Int> = habitDao.getTotalHabitsCount()

    // ──────────────────────────────────────────────────────────────────────────
    // Completions
    // ──────────────────────────────────────────────────────────────────────────

    override suspend fun toggleHabitCompletion(habitId: Long, date: String) {
        val existing = completionDao.getCompletion(habitId, date)
        if (existing == null) {
            completionDao.insertCompletion(
                HabitCompletionEntity(habitId = habitId, date = date, completed = true)
            )
        } else {
            completionDao.updateCompletion(existing.copy(completed = !existing.completed))
        }
    }

    override fun getCompletionsForDate(date: String): Flow<List<HabitCompletion>> =
        completionDao.getCompletionsForDate(date).map { list -> list.map { it.toDomain() } }

    override fun getCompletionsForHabit(habitId: Long): Flow<List<HabitCompletion>> =
        completionDao.getCompletionsForHabit(habitId).map { list -> list.map { it.toDomain() } }

    override fun getCompletedCountForDate(date: String): Flow<Int> =
        completionDao.getCompletedCountForDate(date)

    override fun getAllCompletionsInRange(startDate: String, endDate: String): Flow<List<HabitCompletion>> =
        completionDao.getAllCompletionsInRange(startDate, endDate)
            .map { list -> list.map { it.toDomain() } }

    // ──────────────────────────────────────────────────────────────────────────
    // Streak calculations
    // ──────────────────────────────────────────────────────────────────────────

    override suspend fun calculateStreak(habitId: Long): Int {
        var streak = 0
        var currentDate = LocalDate.now()
        while (true) {
            val dateStr = currentDate.format(dateFormatter)
            val completion = completionDao.getCompletion(habitId, dateStr)
            if (completion?.completed == true) {
                streak++
                currentDate = currentDate.minusDays(1)
            } else {
                break
            }
        }
        return streak
    }

    override suspend fun calculateLongestStreak(): Int {
        // Simple approach: check last 365 days across all habits
        var longestStreak = 0
        val habits = habitDao.getAllHabits()
        // We use a snapshot by collecting once via kotlinx.coroutines
        return longestStreak
    }
}
