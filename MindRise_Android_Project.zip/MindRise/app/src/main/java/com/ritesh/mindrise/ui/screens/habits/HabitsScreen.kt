package com.ritesh.mindrise.ui.screens.habits

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritesh.mindrise.domain.model.HabitWithStatus
import com.ritesh.mindrise.ui.components.*
import com.ritesh.mindrise.ui.theme.*

@Composable
fun HabitsScreen(
    onNavigateToAddHabit: () -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: HabitsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    AnimatedGradientBackground {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                GlassFAB(onClick = onNavigateToAddHabit) {
                    Icon(Icons.Filled.Add, contentDescription = "Add", tint = Color.White)
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                item {
                    GlassTopBar(
                        title = "My Habits",
                        subtitle = "${uiState.habits.size} habits tracked"
                    )
                }

                if (uiState.habits.isEmpty() && !uiState.isLoading) {
                    item {
                        Box(
                            modifier = Modifier.fillParentMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("🏋️", fontSize = 56.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "No habits yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    "Tap + to add your first habit",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                items(uiState.habits, key = { it.habit.id }) { habitWithStatus ->
                    HabitListItem(
                        habitWithStatus = habitWithStatus,
                        onToggle = { viewModel.toggleHabit(habitWithStatus.habit.id) },
                        onDelete = { viewModel.deleteHabit(habitWithStatus) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HabitListItem(
    habitWithStatus: HabitWithStatus,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Habit", color = TextPrimary) },
            text = {
                Text(
                    "Are you sure you want to delete \"${habitWithStatus.habit.title}\"?",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) {
                    Text("Delete", color = AccentPink)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = MidPurple
        )
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = habitWithStatus.habit.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (habitWithStatus.isCompletedToday) {
                        Spacer(Modifier.width(8.dp))
                        Text("✅", fontSize = 14.sp)
                    }
                }
                if (habitWithStatus.habit.description.isNotEmpty()) {
                    Text(
                        text = habitWithStatus.habit.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryChip(habitWithStatus.habit.category)
                    if (!habitWithStatus.habit.reminderTime.isNullOrEmpty()) {
                        Text(
                            "⏰ ${habitWithStatus.habit.reminderTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary
                        )
                    }
                }
            }

            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (habitWithStatus.isCompletedToday) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = "Toggle",
                    tint = if (habitWithStatus.isCompletedToday) AccentGreen else TextTertiary
                )
            }

            IconButton(onClick = { showDeleteDialog = true }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = AccentPink.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
private fun CategoryChip(category: String) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = NeonPurple.copy(alpha = 0.25f)
    ) {
        Text(
            text = category,
            style = MaterialTheme.typography.labelSmall,
            color = NeonViolet,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}
