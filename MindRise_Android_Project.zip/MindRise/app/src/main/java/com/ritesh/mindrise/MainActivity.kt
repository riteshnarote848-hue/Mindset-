package com.ritesh.mindrise

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.rememberNavController
import com.ritesh.mindrise.ui.navigation.MindRiseBottomNav
import com.ritesh.mindrise.ui.navigation.MindRiseNavGraph
import com.ritesh.mindrise.ui.screens.settings.SettingsViewModel
import com.ritesh.mindrise.ui.theme.MindRiseTheme
import com.ritesh.mindrise.util.createNotificationChannel
import com.ritesh.mindrise.util.scheduleDailyReminderCheck
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Set up notification infrastructure
        createNotificationChannel(this)
        scheduleDailyReminderCheck(this)

        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val settingsState by settingsViewModel.uiState.collectAsStateWithLifecycle()

            MindRiseTheme(darkTheme = settingsState.isDarkMode) {
                val navController = rememberNavController()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent,
                    bottomBar = { MindRiseBottomNav(navController = navController) }
                ) { innerPadding ->
                    MindRiseNavGraph(
                        navController = navController,
                    )
                }
            }
        }
    }
}
