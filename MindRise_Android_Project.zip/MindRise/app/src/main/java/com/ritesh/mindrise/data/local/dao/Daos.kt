package com.ritesh.mindrise.data.local.dao

import androidx.room.*
import com.ritesh.mindrise.data.local.entity.HabitCompletionEntity
import com.ritesh.mindrise.data.local.entity.HabitEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for Habit operations.
 */
@Dao
interface HabitDao {

    @Query("SELECT * FROM habits ORDER BY createdAt DESC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits WHERE id = :id")
    suspend fun getHabitById(id: Long): HabitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("SELECT COUNT(*) FROM habits")
    fun getTotalHabitsCount(): Flow<Int>
}

/**
 * Data Access Object for HabitCompletion operations.
 */
@Dao
interface HabitCompletionDao {

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId ORDER BY date DESC")
    fun getCompletionsForHabit(habitId: Long): Flow<List<HabitCompletionEntity>>

    @Query("SELECT * FROM habit_completions WHERE date = :date")
    fun getCompletionsForDate(date: String): Flow<List<HabitCompletionEntity>>

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId AND date = :date LIMIT 1")
    suspend fun getCompletion(habitId: Long, date: String): HabitCompletionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletion(completion: HabitCompletionEntity)

    @Update
    suspend fun updateCompletion(completion: HabitCompletionEntity)

    @Query("SELECT COUNT(*) FROM habit_completions WHERE date = :date AND completed = 1")
    fun getCompletedCountForDate(date: String): Flow<Int>

    @Query("""
        SELECT * FROM habit_completions 
        WHERE habitId = :habitId 
        AND date BETWEEN :startDate AND :endDate 
        ORDER BY date ASC
    """)
    fun getCompletionsInRange(habitId: Long, startDate: String, endDate: String): Flow<List<HabitCompletionEntity>>

    @Query("""
        SELECT * FROM habit_completions 
        WHERE date BETWEEN :startDate AND :endDate 
        ORDER BY date ASC
    """)
    fun getAllCompletionsInRange(startDate: String, endDate: String): Flow<List<HabitCompletionEntity>>

    @Query("""
        SELECT COUNT(*) FROM habit_completions 
        WHERE habitId = :habitId 
        AND completed = 1 
        AND date BETWEEN :startDate AND :endDate
    """)
    suspend fun getCompletedCountInRange(habitId: Long, startDate: String, endDate: String): Int
}
