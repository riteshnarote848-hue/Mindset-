package com.ritesh.mindrise.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.ritesh.mindrise.data.local.dao.HabitCompletionDao
import com.ritesh.mindrise.data.local.dao.HabitDao
import com.ritesh.mindrise.data.local.entity.HabitCompletionEntity
import com.ritesh.mindrise.data.local.entity.HabitEntity

/**
 * Main Room database for the MindRise app.
 */
@Database(
    entities = [HabitEntity::class, HabitCompletionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MindRiseDatabase : RoomDatabase() {
    abstract fun habitDao(): HabitDao
    abstract fun habitCompletionDao(): HabitCompletionDao
}
