package com.ritesh.mindrise.ui.screens.analytics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ritesh.mindrise.domain.model.WeeklyData
import com.ritesh.mindrise.domain.usecase.GetWeeklyAnalyticsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AnalyticsUiState(
    val weeklyData: List<WeeklyData> = emptyList(),
    val totalCompletionsThisWeek: Int = 0,
    val averageCompletionRate: Float = 0f,
    val isLoading: Boolean = true
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val getWeeklyAnalytics: GetWeeklyAnalyticsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(AnalyticsUiState())
    val uiState: StateFlow<AnalyticsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            getWeeklyAnalytics().collect { weeklyData ->
                val totalCompletions = weeklyData.sumOf { it.completedCount }
                val avgRate = if (weeklyData.isNotEmpty() && weeklyData.first().totalCount > 0) {
                    weeklyData.sumOf { it.completedCount }.toFloat() /
                            (weeklyData.size * weeklyData.first().totalCount.coerceAtLeast(1))
                } else 0f

                _uiState.value = AnalyticsUiState(
                    weeklyData = weeklyData,
                    totalCompletionsThisWeek = totalCompletions,
                    averageCompletionRate = avgRate.coerceIn(0f, 1f),
                    isLoading = false
                )
            }
        }
    }
}
