package com.ritesh.mindrise.ui.screens.habits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ritesh.mindrise.domain.model.HabitWithStatus
import com.ritesh.mindrise.domain.usecase.*
import com.ritesh.mindrise.util.today
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HabitsUiState(
    val habits: List<HabitWithStatus> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class HabitsViewModel @Inject constructor(
    private val getHabitsWithStatus: GetHabitsWithStatusUseCase,
    private val toggleCompletion: ToggleHabitCompletionUseCase,
    private val deleteHabit: DeleteHabitUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HabitsUiState())
    val uiState: StateFlow<HabitsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            getHabitsWithStatus().collect { habits ->
                _uiState.value = HabitsUiState(habits = habits, isLoading = false)
            }
        }
    }

    fun toggleHabit(habitId: Long) {
        viewModelScope.launch { toggleCompletion(habitId, today()) }
    }

    fun deleteHabit(habitWithStatus: HabitWithStatus) {
        viewModelScope.launch { deleteHabit(habitWithStatus.habit) }
    }
}
