package com.ritesh.mindrise.ui.screens.addhabit

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritesh.mindrise.domain.model.HabitCategory
import com.ritesh.mindrise.ui.components.*
import com.ritesh.mindrise.ui.theme.*

@Composable
fun AddHabitScreen(
    onNavigateBack: () -> Unit,
    viewModel: AddHabitViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Navigate back after save
    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) onNavigateBack()
    }

    AnimatedGradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            // Top bar with back button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    "New Habit",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // Form Card
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Title
                    GlassTextField(
                        value = uiState.title,
                        onValueChange = viewModel::onTitleChange,
                        label = "Habit Title *",
                        placeholder = "e.g. Morning Meditation",
                        leadingIcon = { Icon(Icons.Filled.Star, null, tint = NeonViolet) },
                        isError = uiState.error != null
                    )

                    if (uiState.error != null) {
                        Text(
                            text = uiState.error!!,
                            color = AccentPink,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Description
                    GlassTextField(
                        value = uiState.description,
                        onValueChange = viewModel::onDescriptionChange,
                        label = "Description (optional)",
                        placeholder = "What's the goal?",
                        leadingIcon = { Icon(Icons.Filled.Notes, null, tint = NeonViolet) },
                        maxLines = 3
                    )

                    // Reminder time
                    GlassTextField(
                        value = uiState.reminderTime,
                        onValueChange = viewModel::onReminderTimeChange,
                        label = "Reminder Time (optional)",
                        placeholder = "e.g. 07:30",
                        leadingIcon = { Icon(Icons.Filled.Schedule, null, tint = NeonViolet) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Category Selector
            SectionHeader("Choose Category")
            CategoryGrid(
                selected = uiState.selectedCategory,
                onSelect = viewModel::onCategorySelect
            )

            Spacer(Modifier.height(24.dp))

            // Save Button
            GlassButton(
                text = "Create Habit ✨",
                onClick = viewModel::saveHabit,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
private fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    leadingIcon: (@Composable () -> Unit)? = null,
    isError: Boolean = false,
    maxLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = TextSecondary) },
        placeholder = { Text(placeholder, color = TextTertiary) },
        leadingIcon = leadingIcon,
        isError = isError,
        maxLines = maxLines,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonPurple,
            unfocusedBorderColor = GlassBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = NeonPurple,
            focusedContainerColor = Color(0x1AFFFFFF),
            unfocusedContainerColor = Color(0x0DFFFFFF),
            errorBorderColor = AccentPink
        )
    )
}

@Composable
private fun CategoryGrid(
    selected: HabitCategory,
    onSelect: (HabitCategory) -> Unit
) {
    val categories = HabitCategory.values()
    Column(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        categories.chunked(3).forEach { rowCats ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                rowCats.forEach { cat ->
                    CategoryChipItem(
                        category = cat,
                        isSelected = cat == selected,
                        onClick = { onSelect(cat) },
                        modifier = Modifier.weight(1f)
                    )
                }
                // fill empty slots
                repeat(3 - rowCats.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun CategoryChipItem(
    category: HabitCategory,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isSelected) NeonPurple.copy(alpha = 0.5f)
                else Color(0x1AFFFFFF)
            )
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) NeonPurple else GlassBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(category.emoji, fontSize = 20.sp)
            Spacer(Modifier.height(2.dp))
            Text(
                text = category.displayName,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) TextPrimary else TextSecondary,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
