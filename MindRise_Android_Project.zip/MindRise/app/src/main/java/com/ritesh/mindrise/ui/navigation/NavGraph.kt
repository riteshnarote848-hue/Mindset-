package com.ritesh.mindrise.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.ritesh.mindrise.ui.screens.addhabit.AddHabitScreen
import com.ritesh.mindrise.ui.screens.analytics.AnalyticsScreen
import com.ritesh.mindrise.ui.screens.dashboard.DashboardScreen
import com.ritesh.mindrise.ui.screens.habits.HabitsScreen
import com.ritesh.mindrise.ui.screens.settings.SettingsScreen

/**
 * All navigation route strings for the app.
 */
sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object Habits : Screen("habits")
    object AddHabit : Screen("add_habit?habitId={habitId}") {
        fun createRoute(habitId: Long? = null) =
            if (habitId != null) "add_habit?habitId=$habitId" else "add_habit"
    }
    object Analytics : Screen("analytics")
    object Settings : Screen("settings")
}

/**
 * Root navigation graph for MindRise.
 */
@Composable
fun MindRiseNavGraph(
    navController: NavHostController,
    startDestination: String = Screen.Dashboard.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigateToHabits = { navController.navigate(Screen.Habits.route) },
                onNavigateToAddHabit = { navController.navigate(Screen.AddHabit.createRoute()) },
                onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.Habits.route) {
            HabitsScreen(
                onNavigateToAddHabit = { navController.navigate(Screen.AddHabit.createRoute()) },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.AddHabit.route,
            arguments = listOf(
                navArgument("habitId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) {
            AddHabitScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Analytics.route) {
            AnalyticsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
