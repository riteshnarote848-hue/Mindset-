package com.ritesh.mindrise.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing a habit tracked by the user.
 */
@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val category: String,
    val reminderTime: String?, // "HH:mm" format, nullable if no reminder
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Room entity representing a single day's completion of a habit.
 */
@Entity(
    tableName = "habit_completions",
    foreignKeys = [
        androidx.room.ForeignKey(
            entity = HabitEntity::class,
            parentColumns = ["id"],
            childColumns = ["habitId"],
            onDelete = androidx.room.ForeignKey.CASCADE
        )
    ],
    indices = [androidx.room.Index(value = ["habitId", "date"], unique = true)]
)
data class HabitCompletionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val habitId: Long,
    val date: String, // "yyyy-MM-dd" format
    val completed: Boolean = false
)
