package com.ritesh.mindrise.domain.repository

import com.ritesh.mindrise.domain.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Repository contract for habit data operations.
 */
interface HabitRepository {

    fun getAllHabits(): Flow<List<Habit>>

    suspend fun getHabitById(id: Long): Habit?

    suspend fun addHabit(habit: Habit): Long

    suspend fun updateHabit(habit: Habit)

    suspend fun deleteHabit(habit: Habit)

    fun getTotalHabitsCount(): Flow<Int>

    suspend fun toggleHabitCompletion(habitId: Long, date: String)

    fun getCompletionsForDate(date: String): Flow<List<HabitCompletion>>

    fun getCompletionsForHabit(habitId: Long): Flow<List<HabitCompletion>>

    fun getCompletedCountForDate(date: String): Flow<Int>

    fun getAllCompletionsInRange(startDate: String, endDate: String): Flow<List<HabitCompletion>>

    suspend fun calculateStreak(habitId: Long): Int

    suspend fun calculateLongestStreak(): Int
}
