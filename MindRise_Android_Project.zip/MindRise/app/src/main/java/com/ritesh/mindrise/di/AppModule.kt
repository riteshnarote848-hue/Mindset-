package com.ritesh.mindrise.di

import android.content.Context
import androidx.room.Room
import androidx.work.WorkManager
import com.ritesh.mindrise.data.local.dao.HabitCompletionDao
import com.ritesh.mindrise.data.local.dao.HabitDao
import com.ritesh.mindrise.data.local.database.MindRiseDatabase
import com.ritesh.mindrise.data.repository.HabitRepositoryImpl
import com.ritesh.mindrise.domain.repository.HabitRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MindRiseDatabase =
        Room.databaseBuilder(
            context,
            MindRiseDatabase::class.java,
            "mindrise_database"
        ).build()

    @Provides
    fun provideHabitDao(db: MindRiseDatabase): HabitDao = db.habitDao()

    @Provides
    fun provideHabitCompletionDao(db: MindRiseDatabase): HabitCompletionDao = db.habitCompletionDao()

    @Provides
    @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager =
        WorkManager.getInstance(context)
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindHabitRepository(impl: HabitRepositoryImpl): HabitRepository
}
