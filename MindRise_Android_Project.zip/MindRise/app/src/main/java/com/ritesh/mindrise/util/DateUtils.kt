package com.ritesh.mindrise.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter

val DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
val DISPLAY_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")

fun today(): String = LocalDate.now().format(DATE_FORMATTER)

fun LocalDate.toDisplayString(): String = this.format(DISPLAY_FORMATTER)
fun LocalDate.toDbString(): String = this.format(DATE_FORMATTER)

fun String.toLocalDate(): LocalDate = LocalDate.parse(this, DATE_FORMATTER)
