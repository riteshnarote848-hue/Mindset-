package com.ritesh.mindrise.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ritesh.mindrise.domain.model.DashboardStats
import com.ritesh.mindrise.domain.model.HabitWithStatus
import com.ritesh.mindrise.domain.usecase.*
import com.ritesh.mindrise.util.today
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val stats: DashboardStats = DashboardStats(),
    val todayHabits: List<HabitWithStatus> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val getDashboardStats: GetDashboardStatsUseCase,
    private val getHabitsWithStatus: GetHabitsWithStatusUseCase,
    private val toggleHabitCompletion: ToggleHabitCompletionUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            combine(
                getDashboardStats(),
                getHabitsWithStatus()
            ) { stats, habits ->
                DashboardUiState(
                    stats = stats,
                    todayHabits = habits,
                    isLoading = false
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun toggleHabit(habitId: Long) {
        viewModelScope.launch {
            toggleHabitCompletion(habitId, today())
        }
    }
}
