package com.ritesh.mindrise.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritesh.mindrise.ui.components.*
import com.ritesh.mindrise.ui.theme.*

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    AnimatedGradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            GlassTopBar(title = "Settings", subtitle = "Customize your experience")

            // App Info Card
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🧠", fontSize = 48.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "MindRise",
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Habit Tracker v1.0",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionHeader("Preferences")

            // Dark Mode Toggle
            SettingsToggleItem(
                icon = if (uiState.isDarkMode) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                title = "Dark Mode",
                subtitle = if (uiState.isDarkMode) "Dark theme enabled" else "Light theme enabled",
                checked = uiState.isDarkMode,
                onCheckedChange = viewModel::toggleDarkMode
            )

            // Notifications Toggle
            SettingsToggleItem(
                icon = if (uiState.isNotificationsEnabled) Icons.Filled.Notifications else Icons.Filled.NotificationsOff,
                title = "Notifications",
                subtitle = if (uiState.isNotificationsEnabled) "Daily reminders active" else "Reminders paused",
                checked = uiState.isNotificationsEnabled,
                onCheckedChange = viewModel::toggleNotifications
            )

            Spacer(Modifier.height(16.dp))
            SectionHeader("About")

            SettingsInfoItem(
                icon = Icons.Filled.Info,
                title = "Version",
                subtitle = "1.0.0 – Production Build"
            )

            SettingsInfoItem(
                icon = Icons.Filled.Security,
                title = "Privacy",
                subtitle = "All data stored locally on device"
            )

            SettingsInfoItem(
                icon = Icons.Filled.Favorite,
                title = "Built with",
                subtitle = "Jetpack Compose · Room · Hilt · MVVM"
            )

            Spacer(Modifier.height(24.dp))

            // Motivational quote
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("💡", fontSize = 24.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "\"We are what we repeatedly do. Excellence, then, is not an act, but a habit.\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "— Aristotle",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonViolet,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = NeonViolet, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = NeonPurple,
                    uncheckedTrackColor = GlassWhite
                )
            )
        }
    }
}

@Composable
private fun SettingsInfoItem(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = NeonViolet, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}
