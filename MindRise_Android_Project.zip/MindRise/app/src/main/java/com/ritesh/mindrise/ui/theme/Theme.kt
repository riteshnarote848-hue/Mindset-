package com.ritesh.mindrise.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Brand Palette ─────────────────────────────────────────────────────────────
val DeepPurple = Color(0xFF1A0533)
val MidPurple = Color(0xFF2D1B69)
val NeonPurple = Color(0xFF7B2FBE)
val NeonViolet = Color(0xFFAB47BC)
val CyberBlue = Color(0xFF0D47A1)
val ElectricBlue = Color(0xFF1565C0)
val GlassWhite = Color(0x33FFFFFF)       // alpha 0.2
val GlassWhiteMid = Color(0x55FFFFFF)    // alpha 0.33
val GlassBorder = Color(0x66FFFFFF)      // alpha 0.4
val GlowPurple = Color(0x88AB47BC)
val GlowBlue = Color(0x881565C0)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xCCFFFFFF)    // 80% white
val TextTertiary = Color(0x99FFFFFF)     // 60% white
val AccentGreen = Color(0xFF69F0AE)
val AccentOrange = Color(0xFFFFAB40)
val AccentPink = Color(0xFFFF4081)
val SurfaceDark = Color(0xFF12002A)
val CardSurface = Color(0x1AFFFFFF)

// Light scheme (minimally used – app is dark-first)
val LightBackground = Color(0xFFF3E5F5)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1A0533)

private val DarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = Color.White,
    primaryContainer = MidPurple,
    onPrimaryContainer = Color.White,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    secondaryContainer = CyberBlue,
    onSecondaryContainer = Color.White,
    tertiary = AccentGreen,
    background = DeepPurple,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = MidPurple,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = AccentPink,
)

private val LightColorScheme = lightColorScheme(
    primary = NeonPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE7F6),
    onPrimaryContainer = DeepPurple,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
)

@Composable
fun MindRiseTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MindRiseTypography,
        content = content
    )
}
