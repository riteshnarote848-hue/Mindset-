package com.ritesh.mindrise.ui.screens.addhabit

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ritesh.mindrise.domain.model.Habit
import com.ritesh.mindrise.domain.model.HabitCategory
import com.ritesh.mindrise.domain.usecase.AddHabitUseCase
import com.ritesh.mindrise.domain.usecase.GetAllHabitsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AddHabitUiState(
    val title: String = "",
    val description: String = "",
    val selectedCategory: HabitCategory = HabitCategory.OTHER,
    val reminderTime: String = "",
    val isSaved: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class AddHabitViewModel @Inject constructor(
    private val addHabit: AddHabitUseCase,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddHabitUiState())
    val uiState: StateFlow<AddHabitUiState> = _uiState.asStateFlow()

    fun onTitleChange(value: String) { _uiState.update { it.copy(title = value, error = null) } }
    fun onDescriptionChange(value: String) { _uiState.update { it.copy(description = value) } }
    fun onCategorySelect(cat: HabitCategory) { _uiState.update { it.copy(selectedCategory = cat) } }
    fun onReminderTimeChange(value: String) { _uiState.update { it.copy(reminderTime = value) } }

    fun saveHabit() {
        val state = _uiState.value
        if (state.title.isBlank()) {
            _uiState.update { it.copy(error = "Habit title is required") }
            return
        }
        viewModelScope.launch {
            addHabit(
                Habit(
                    title = state.title.trim(),
                    description = state.description.trim(),
                    category = state.selectedCategory.name,
                    reminderTime = state.reminderTime.ifBlank { null }
                )
            )
            _uiState.update { it.copy(isSaved = true) }
        }
    }
}
