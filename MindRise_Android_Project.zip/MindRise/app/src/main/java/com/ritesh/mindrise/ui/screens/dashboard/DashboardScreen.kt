package com.ritesh.mindrise.ui.screens.dashboard

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritesh.mindrise.domain.model.HabitWithStatus
import com.ritesh.mindrise.ui.components.*
import com.ritesh.mindrise.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun DashboardScreen(
    onNavigateToHabits: () -> Unit,
    onNavigateToAddHabit: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val greeting = remember { getGreeting() }
    val dateStr = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMM d"))
    }

    AnimatedGradientBackground {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                GlassFAB(onClick = onNavigateToAddHabit) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Habit", tint = Color.White)
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                // Header
                item {
                    GlassTopBar(
                        title = greeting,
                        subtitle = dateStr
                    )
                }

                // Stats Row
                item {
                    StatsSection(uiState = uiState)
                }

                // Progress Circle
                item {
                    ProgressSection(uiState = uiState)
                }

                // Today's Habits
                item {
                    SectionHeader(
                        title = "Today's Habits",
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                if (uiState.todayHabits.isEmpty() && !uiState.isLoading) {
                    item { EmptyHabitsPrompt(onNavigateToAddHabit) }
                }

                items(
                    items = uiState.todayHabits,
                    key = { it.habit.id }
                ) { habitWithStatus ->
                    HabitCard(
                        habitWithStatus = habitWithStatus,
                        onToggle = { viewModel.toggleHabit(habitWithStatus.habit.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatsSection(uiState: DashboardUiState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard(
            value = uiState.stats.totalHabits.toString(),
            label = "Total Habits",
            emoji = "📋",
            modifier = Modifier.weight(1f),
            glowColor = GlowPurple
        )
        StatCard(
            value = uiState.stats.completedToday.toString(),
            label = "Done Today",
            emoji = "✅",
            modifier = Modifier.weight(1f),
            glowColor = GlowBlue
        )
        StatCard(
            value = uiState.stats.longestStreak.toString(),
            label = "Best Streak",
            emoji = "🔥",
            modifier = Modifier.weight(1f),
            glowColor = Color(0x88FF6B35)
        )
    }
}

@Composable
private fun ProgressSection(uiState: DashboardUiState) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Today's Progress",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${uiState.stats.completedToday} / ${uiState.stats.totalHabits} completed",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(12.dp))
                if (uiState.stats.completedToday == uiState.stats.totalHabits && uiState.stats.totalHabits > 0) {
                    StreakBadge(streak = uiState.stats.completedToday)
                }
            }
            AnimatedProgressCircle(
                progress = uiState.stats.completionRate,
                size = 88.dp,
                label = "${(uiState.stats.completionRate * 100).toInt()}%"
            )
        }
    }
}

@Composable
private fun HabitCard(
    habitWithStatus: HabitWithStatus,
    onToggle: () -> Unit
) {
    val habit = habitWithStatus.habit
    val isCompleted = habitWithStatus.isCompletedToday

    val checkAlpha by animateFloatAsState(
        targetValue = if (isCompleted) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "check_anim"
    )

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        glowColor = if (isCompleted) Color(0x8869F0AE) else GlowPurple
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category emoji
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isCompleted) AccentGreen.copy(alpha = 0.2f)
                        else NeonPurple.copy(alpha = 0.2f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(getCategoryEmoji(habit.category), fontSize = 20.sp)
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = habit.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isCompleted) AccentGreen else TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                if (habit.description.isNotEmpty()) {
                    Text(
                        text = habit.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
                if (!habit.reminderTime.isNullOrEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Schedule,
                            contentDescription = null,
                            tint = TextTertiary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(2.dp))
                        Text(
                            text = habit.reminderTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary
                        )
                    }
                }
            }

            // Completion toggle
            IconButton(onClick = onToggle) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isCompleted) AccentGreen.copy(alpha = 0.3f)
                            else GlassWhite
                        )
                        .border(
                            1.dp,
                            if (isCompleted) AccentGreen else GlassBorder,
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Complete",
                        tint = AccentGreen.copy(alpha = checkAlpha.coerceAtLeast(0.1f)),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyHabitsPrompt(onAdd: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🌱", fontSize = 48.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Start your journey",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Add your first habit and begin building discipline",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(16.dp))
            GlassButton(text = "Add First Habit", onClick = onAdd)
        }
    }
}

private fun getGreeting(): String {
    return when (LocalDate.now().dayOfWeek.value) {
        1 -> "New Week, New Goals 🚀"
        5, 6, 7 -> "Weekend Warrior! 💪"
        else -> "Good to see you! ✨"
    }
}

private fun getCategoryEmoji(category: String): String = when (category) {
    "HEALTH" -> "💪"
    "MINDFULNESS" -> "🧘"
    "LEARNING" -> "📚"
    "FITNESS" -> "🏃"
    "PRODUCTIVITY" -> "⚡"
    "SOCIAL" -> "👥"
    "CREATIVITY" -> "🎨"
    "FINANCE" -> "💰"
    else -> "✨"
}
