package com.ritesh.mindrise.ui.screens.analytics

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritesh.mindrise.domain.model.WeeklyData
import com.ritesh.mindrise.ui.components.*
import com.ritesh.mindrise.ui.theme.*

@Composable
fun AnalyticsScreen(
    onNavigateBack: () -> Unit,
    viewModel: AnalyticsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    AnimatedGradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            GlassTopBar(title = "Analytics", subtitle = "Track your progress")

            // Summary cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    value = uiState.totalCompletionsThisWeek.toString(),
                    label = "This Week",
                    emoji = "📊",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    value = "${(uiState.averageCompletionRate * 100).toInt()}%",
                    label = "Avg Rate",
                    emoji = "🎯",
                    modifier = Modifier.weight(1f),
                    glowColor = GlowBlue
                )
            }

            Spacer(Modifier.height(16.dp))

            // Weekly bar chart
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Weekly Overview",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Last 7 days completion",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(24.dp))

                    if (uiState.weeklyData.isNotEmpty()) {
                        WeeklyBarChart(data = uiState.weeklyData)
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No data yet", color = TextSecondary)
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Progress ring summary
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            "Average Completion",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${uiState.totalCompletionsThisWeek} completions this week",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        val msg = when {
                            uiState.averageCompletionRate >= 0.8f -> "🔥 Excellent work!"
                            uiState.averageCompletionRate >= 0.5f -> "👍 Good progress!"
                            uiState.averageCompletionRate > 0f -> "💪 Keep going!"
                            else -> "🌱 Start tracking!"
                        }
                        Text(msg, style = MaterialTheme.typography.bodyMedium, color = AccentGreen)
                    }

                    AnimatedProgressCircle(
                        progress = uiState.averageCompletionRate,
                        size = 96.dp,
                        strokeWidth = 10.dp,
                        label = "${(uiState.averageCompletionRate * 100).toInt()}%"
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Day breakdown
            if (uiState.weeklyData.isNotEmpty()) {
                SectionHeader("Day Breakdown")
                uiState.weeklyData.forEach { day ->
                    DayRow(data = day)
                }
            }
        }
    }
}

@Composable
private fun WeeklyBarChart(data: List<WeeklyData>) {
    val maxValue = data.maxOf { it.totalCount.coerceAtLeast(1) }.toFloat()

    val animSpec = tween<Float>(durationMillis = 1000, easing = FastOutSlowInEasing)
    val animatedHeights = data.mapIndexed { index, _ ->
        val targetHeight = data[index].completedCount.toFloat() / maxValue
        val animatedValue by animateFloatAsState(
            targetValue = targetHeight,
            animationSpec = animSpec,
            label = "bar_$index"
        )
        animatedValue
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEachIndexed { index, day ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = day.completedCount.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .fillMaxHeight(animatedHeights[index].coerceAtLeast(0.03f))
                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    NeonViolet,
                                    NeonPurple.copy(alpha = 0.5f)
                                )
                            )
                        )
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = day.dayLabel.take(3),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun DayRow(data: WeeklyData) {
    val rate = if (data.totalCount > 0) data.completedCount.toFloat() / data.totalCount else 0f
    val animatedRate by animateFloatAsState(
        targetValue = rate,
        animationSpec = tween(800),
        label = "day_rate"
    )

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = data.dayLabel,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.width(40.dp)
            )
            Spacer(Modifier.width(8.dp))
            // Progress bar
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(GlassWhite)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedRate)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(NeonPurple, ElectricBlue)
                            )
                        )
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "${data.completedCount}/${data.totalCount}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.width(36.dp)
            )
        }
    }
}
